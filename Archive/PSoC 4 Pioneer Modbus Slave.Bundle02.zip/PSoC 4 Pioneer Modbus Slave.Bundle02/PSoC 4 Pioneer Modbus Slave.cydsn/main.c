/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

uint8 flag = 0;

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    uint8 ch;  
    /* Start the SCB UART */
    UART_Start();
    
    /* Start the Interrupt */
    UART_RX_FULL_Start();
    
    /* Transmit string through UART */
    UART_UartPutString("UART Initialised");

    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        TX_LED_Write(flag);
        ch = UART_UartGetChar();
          
        if(flag == 1)
        {
          flag = 0;
          UART_UartPutChar(ch);
          TX_LED_Write(flag);       
        }      

    }
}

/* [] END OF FILE */
